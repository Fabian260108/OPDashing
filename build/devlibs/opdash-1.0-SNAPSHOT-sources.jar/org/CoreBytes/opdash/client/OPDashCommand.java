package org.CoreBytes.opdash.client;

import com.mojang.brigadier.Command;
import com.mojang.brigadier.arguments.DoubleArgumentType;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

public class OPDashCommand {

    public static void registerCommands(ConfigManager config, OPDashHUD hud) {
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> {
            dispatcher.register(
                    ClientCommandManager.literal("opdash")
                            .then(ClientCommandManager.literal("hud")
                                    .then(ClientCommandManager.literal("toggle")
                                            .executes(ctx -> {
                                                hud.toggleHUD();
                                                String status = hud.isHudEnabled() ? "eingeschaltet" : "ausgeschaltet";
                                                MinecraftClient.getInstance().player.sendMessage(
                                                        Text.literal("OPDash HUD " + status).formatted(Formatting.GREEN), false
                                                );
                                                return Command.SINGLE_SUCCESS;
                                            })
                                    )
                            )
                            .then(ClientCommandManager.literal("reset")
                                    .executes(ctx -> {
                                        config.resetShards();
                                        // Reset Buy und Sell
                                        config.addBuy(-config.getTotalBuy()); // setze auf 0
                                        config.addSell(-config.getTotalSell()); // setze auf 0

                                        MinecraftClient.getInstance().player.sendMessage(
                                                Text.literal("OPShards, Buy und Sell zurückgesetzt").formatted(Formatting.RED), false
                                        );
                                        return Command.SINGLE_SUCCESS;
                                    })
                            )
                            .then(ClientCommandManager.literal("goal")
                                    .then(ClientCommandManager.argument("value", DoubleArgumentType.doubleArg(0))
                                            .executes(ctx -> {
                                                double goal = DoubleArgumentType.getDouble(ctx, "value");
                                                config.setShardsGoal(goal);
                                                MinecraftClient.getInstance().player.sendMessage(
                                                        Text.literal("Shards-Ziel gesetzt: " + goal).formatted(Formatting.AQUA), false
                                                );
                                                return Command.SINGLE_SUCCESS;
                                            })
                                    )
                            )
                            .then(ClientCommandManager.literal("progress")
                                    .executes(ctx -> {
                                        double total = config.getDouble("totalShards", 0.0);
                                        double goal = config.getDouble("shardsGoal", 0.0);
                                        double remaining = goal - total;
                                        if (remaining < 0) remaining = 0;

                                        String message = String.format("OPShards: %.2f | Ziel: %.2f | Verbleibend: %.2f", total, goal, remaining)
                                                .replace('.', ',');
                                        MinecraftClient.getInstance().player.sendMessage(
                                                Text.literal(message).formatted(Formatting.YELLOW), false
                                        );
                                        return Command.SINGLE_SUCCESS;
                                    })
                            )
            );
        });
    }
}
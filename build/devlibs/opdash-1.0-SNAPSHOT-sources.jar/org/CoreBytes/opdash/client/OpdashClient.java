package org.CoreBytes.opdash.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class OpdashClient implements ClientModInitializer {

    public static ConfigManager shardsConfig;
    public static OPDashHUD hud;

    // ROBUSTES REGEX (ohne OPSUCHT Prefix!)
    private static final Pattern EXCHANGE_PATTERN = Pattern.compile(
            "Du hast (\\d+)x ([^ ]+) in ([\\d,.]+) OPShards umgetauscht"
    );

    @Override
    public void onInitializeClient() {

        shardsConfig = new ConfigManager();
        hud = new OPDashHUD(shardsConfig);

        ClientReceiveMessageEvents.ALLOW_GAME.register((message, overlay) -> {
            handleMessage(message.getString());
            return true;
        });
    }

    private void handleMessage(String rawMsg) {

        if (rawMsg == null) return;

        // Farben entfernen (wichtig für OPSUCHT)
        String msg = rawMsg.replaceAll("§.", "");

        Matcher matcher = EXCHANGE_PATTERN.matcher(msg);

        if (!matcher.find()) {
            return;
        }

        int amount = Integer.parseInt(matcher.group(1));
        String item = matcher.group(2).toLowerCase();
        double shards = Double.parseDouble(matcher.group(3).replace(",", "."));


        shardsConfig.addShards(shards);

        // Nur diese zwei Items erlauben
        if (item.contains("diamant")) {
            OPDashAPI.updateConfigFromAPI(shardsConfig, "diamond_block", amount);
        }
        else if (item.contains("netherite")) {
            OPDashAPI.updateConfigFromAPI(shardsConfig, "netherite_ingot", amount);
        }
        else {
            return;
        }

        // Optional Feedback
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player != null) {
            client.player.sendMessage(Text.literal("§aTrade erkannt: " + amount + "x " + item), false);
        }
    }
}
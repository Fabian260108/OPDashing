package org.CoreBytes.opdash.client;

import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3675;
import net.minecraft.class_9779;
import org.lwjgl.glfw.GLFW;

public class OPDashHUD {

    public static String formatMoney(double value) {
        if (value >= 1_000_000_000) return String.format("%.2fB", value / 1_000_000_000).replace('.', ',');
        if (value >= 1_000_000) return String.format("%.2fM", value / 1_000_000).replace('.', ',');
        if (value >= 1_000) return String.format("%.2fk", value / 1_000).replace('.', ',');
        return String.format("%.2f", value).replace('.', ',');
    }

    private final ConfigManager shardsConfig;
    private final OPDashHUDConfig hudConfig;

    private boolean hudEnabled = true;
    private boolean moveModeActive = false;

    private boolean dragging = false;
    private int dragOffsetX = 0;
    private int dragOffsetY = 0;

    private final class_304 moveHUDKey;

    public OPDashHUD(ConfigManager shardsConfig) {
        this.shardsConfig = shardsConfig;
        this.hudConfig = new OPDashHUDConfig();

        moveHUDKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "OPDash.moveHUD",
                class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_H,
                "OPDash"
        ));
    }

    public void toggleHUD() { hudEnabled = !hudEnabled; }
    public boolean isHudEnabled() { return hudEnabled; }

    public void tick(class_310 client) {
        if (moveHUDKey.method_1436() && !moveModeActive) {
            moveModeActive = true;
            client.method_1507(new OPDashMoveHudScreen(this));
        }
    }

    public void render(class_332 context) {
        if (!hudEnabled) return;
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null) return;

        int x = hudConfig.getX();
        int y = hudConfig.getY();

        // Werte aus Config
        String shards = String.format("%.2f", shardsConfig.getTotalShards()).replace('.', ',');
        String goal = String.format("%.2f", shardsConfig.getShardsGoal()).replace('.', ',');
        String buy = formatMoney(shardsConfig.getTotalBuy());
        String sell = formatMoney(shardsConfig.getTotalSell());

        int width = Math.max(Math.max(Math.max(
                                client.field_1772.method_1727("OPShards: " + shards),
                                client.field_1772.method_1727("Goal: " + goal)),
                        client.field_1772.method_1727("Buy: " + buy)),
                client.field_1772.method_1727("Sell: " + sell)) + 10;
        int height = 60;

        context.method_25294(x, y, x + width, y + height, 0xAA222222);

        int labelColor = 0xFFAAAAAA;
        int valueColor = 0xFF55DDFF;

        context.method_51433(client.field_1772, "OPShards:", x + 5, y, labelColor, false);
        context.method_51433(client.field_1772, shards, x + 5 + client.field_1772.method_1727("OPShards: "), y, valueColor, false);

        context.method_51433(client.field_1772, "Goal:", x + 5, y + 15, labelColor, false);
        context.method_51433(client.field_1772, goal, x + 5 + client.field_1772.method_1727("Goal: "), y + 15, valueColor, false);

        context.method_51433(client.field_1772, "Buy:", x + 5, y + 30, labelColor, false);
        context.method_51433(client.field_1772, buy, x + 5 + client.field_1772.method_1727("Buy: "), y + 30, valueColor, false);

        context.method_51433(client.field_1772, "Sell:", x + 5, y + 45, labelColor, false);
        context.method_51433(client.field_1772, sell, x + 5 + client.field_1772.method_1727("Sell: "), y + 45, valueColor, false);
    }

    public void renderOverlay(class_332 context, int mouseX, int mouseY) {
        render(context);

        class_310 client = class_310.method_1551();

        int x = hudConfig.getX();
        int y = hudConfig.getY();
        int width = getHudWidth(client);
        int height = getHudHeight();

        context.method_25294(x, y, x + width, y + height, 0x66444444);

        context.method_51433(client.field_1772,
                "HUD Move Mode - Linksklick & ziehen, ESC zum Beenden",
                x, y - 12, 0xFFFFFF, false);
    }

    public void startDragging(int mouseX, int mouseY) {
        class_310 client = class_310.method_1551();

        int x = hudConfig.getX();
        int y = hudConfig.getY();
        int width = getHudWidth(client);
        int height = getHudHeight();

        if (mouseX >= x && mouseX <= x + width &&
                mouseY >= y && mouseY <= y + height) {

            dragging = true;
            dragOffsetX = mouseX - x;
            dragOffsetY = mouseY - y;
        }
    }
    public void dragTo(int mouseX, int mouseY) {
        if (dragging) {
            hudConfig.setX(mouseX - dragOffsetX);
            hudConfig.setY(mouseY - dragOffsetY);
        }
    }

    public void stopDragging() { dragging = false; }

    public OPDashHUDConfig getHudConfig() { return hudConfig; }

    public void setMoveModeActive(boolean active) { moveModeActive = active; }

    public void render(class_332 drawContext, class_9779 renderTickCounter) {
        render(drawContext);
    }

    private int getHudWidth(class_310 client) {
        String shards = String.format("%.2f", shardsConfig.getTotalShards()).replace('.', ',');
        String goal = String.format("%.2f", shardsConfig.getShardsGoal()).replace('.', ',');
        String buy = formatMoney(shardsConfig.getTotalBuy());
        String sell = formatMoney(shardsConfig.getTotalSell());

        return Math.max(Math.max(Math.max(
                                client.field_1772.method_1727("OPShards: " + shards),
                                client.field_1772.method_1727("Goal: " + goal)),
                        client.field_1772.method_1727("Buy: " + buy)),
                client.field_1772.method_1727("Sell: " + sell)) + 10;
    }

    private int getHudHeight() {
        return 60;
    }
}
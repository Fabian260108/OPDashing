package org.CoreBytes.opdash.client;

import com.mojang.brigadier.Command;
import com.mojang.brigadier.arguments.DoubleArgumentType;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_310;

public class OPDashCommand {

    public static void registerCommands(ConfigManager config, OPDashHUD hud) {
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> {
            dispatcher.register(
                    ClientCommandManager.literal("opdash")
                            .then(ClientCommandManager.literal("hud")
                                    .then(ClientCommandManager.literal("toggle")
                                            .executes(ctx -> {
                                                hud.toggleHUD();
                                                String status = hud.isHudEnabled() ? "eingeschaltet" : "ausgeschaltet";
                                                class_310.method_1551().field_1724.method_7353(
                                                        class_2561.method_43470("OPDash HUD " + status).method_27692(class_124.field_1060), false
                                                );
                                                return Command.SINGLE_SUCCESS;
                                            })
                                    )
                            )
                            .then(ClientCommandManager.literal("reset")
                                    .executes(ctx -> {
                                        config.resetShards();
                                        // Reset Buy und Sell
                                        config.addBuy(-config.getTotalBuy()); // setze auf 0
                                        config.addSell(-config.getTotalSell()); // setze auf 0

                                        class_310.method_1551().field_1724.method_7353(
                                                class_2561.method_43470("OPShards, Buy und Sell zurückgesetzt").method_27692(class_124.field_1061), false
                                        );
                                        return Command.SINGLE_SUCCESS;
                                    })
                            )
                            .then(ClientCommandManager.literal("goal")
                                    .then(ClientCommandManager.argument("value", DoubleArgumentType.doubleArg(0))
                                            .executes(ctx -> {
                                                double goal = DoubleArgumentType.getDouble(ctx, "value");
                                                config.setShardsGoal(goal);
                                                class_310.method_1551().field_1724.method_7353(
                                                        class_2561.method_43470("Shards-Ziel gesetzt: " + goal).method_27692(class_124.field_1075), false
                                                );
                                                return Command.SINGLE_SUCCESS;
                                            })
                                    )
                            )
                            .then(ClientCommandManager.literal("progress")
                                    .executes(ctx -> {
                                        double total = config.getDouble("totalShards", 0.0);
                                        double goal = config.getDouble("shardsGoal", 0.0);
                                        double remaining = goal - total;
                                        if (remaining < 0) remaining = 0;

                                        String message = String.format("OPShards: %.2f | Ziel: %.2f | Verbleibend: %.2f", total, goal, remaining)
                                                .replace('.', ',');
                                        class_310.method_1551().field_1724.method_7353(
                                                class_2561.method_43470(message).method_27692(class_124.field_1054), false
                                        );
                                        return Command.SINGLE_SUCCESS;
                                    })
                            )
            );
        });
    }
}
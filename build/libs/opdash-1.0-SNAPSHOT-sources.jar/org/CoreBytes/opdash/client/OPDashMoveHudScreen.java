package org.CoreBytes.opdash.client;

import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_437;

public class OPDashMoveHudScreen extends class_437 {

    private final OPDashHUD hud;

    public OPDashMoveHudScreen(OPDashHUD hud) {
        super(class_2561.method_30163("Move HUD"));
        this.hud = hud;

        // Cursor sichtbar erzwingen
        class_310.method_1551().field_1729.method_1610();
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        super.method_25394(context, mouseX, mouseY, delta);
        hud.renderOverlay(context, mouseX, mouseY);
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        if (button == 0) {
            hud.startDragging((int) mouseX, (int) mouseY);
            return true;
        }
        return true; // unbedingt true, damit Minecraft die Maus nicht selbst behandelt
    }

    @Override
    public boolean method_25406(double mouseX, double mouseY, int button) {
        if (button == 0) {
            hud.stopDragging();
            return true;
        }
        return true;
    }

    @Override
    public boolean method_25403(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        if (button == 0) {
            hud.dragTo((int) mouseX, (int) mouseY);
            return true;
        }
        return true;
    }

    @Override
    public void method_25432() {
        // MoveMode beendet
        hud.setMoveModeActive(false);
        super.method_25432();
    }

    @Override
    public boolean method_25421() { return false; }
}